"use client";

import { useState, useEffect, useRef } from "react";
import { useParams } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  FileText,
  Link as LinkIcon,
  Upload,
  Plus,
  X,
  Loader2,
  Trash2,
  ExternalLink,
  Sparkles,
  Archive,
  AlertTriangle,
  Calendar,
  Target,
} from "lucide-react";

interface Resource {
  type: "pdf" | "link";
  name: string;
  url: string;
  file_size?: number;
}

interface Project {
  id: string;
  title: string;
  description: string | null;
  resources: string | null;
  created_at: string;
  updated_at: string;
  created_by: string | null;
  community_id: string | null;
  challenge_id: string | null;
}

export default function RessourcesProjetPage() {
  const params = useParams();
  const projectId = params.id as string;

  const [project, setProject] = useState<Project | null>(null);
  const [resources, setResources] = useState<Resource[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showLinkForm, setShowLinkForm] = useState(false);
  const [newLinkName, setNewLinkName] = useState("");
  const [newLinkUrl, setNewLinkUrl] = useState("");
  const [isAdding, setIsAdding] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [aiData, setAiData] = useState<any>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [progressLog, setProgressLog] = useState<string | null>(null);
  const [nudge, setNudge] = useState<any>(null);
  const [heritage, setHeritage] = useState<any>(null);
  const [activeAiTab, setActiveAiTab] = useState<'roadmap' | 'pitch' | 'readme' | 'resources' | 'heritage'>('roadmap');

  useEffect(() => {
    let cancelled = false;

    async function fetchProject() {
      try {
        const res = await fetch(`/api/projects/${projectId}`);
        if (res.ok && !cancelled) {
          const { project: data } = await res.json();
          if (data) {
            setProject(data);
            setResources(data.parsed_resources || []);
          }
        }
      } catch (err) {
        console.error("Erreur chargement projet:", err);
      } finally {
        if (!cancelled) setIsLoading(false);
      }
    }

    fetchProject();
    return () => { cancelled = true; };
  }, [projectId]);

  const saveResources = async (newResources: Resource[]) => {
    await fetch(`/api/projects/${projectId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ resources: newResources }),
    });
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    setIsAdding(true);
    const newResources = [...resources];

    for (const file of Array.from(files)) {
      if (file.type === "application/pdf") {
        newResources.push({
          type: "pdf",
          name: file.name,
          url: URL.createObjectURL(file),
          file_size: file.size,
        });
      }
    }

    setResources(newResources);
    await saveResources(newResources);
    setIsAdding(false);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const addLink = async () => {
    if (!newLinkName.trim() || !newLinkUrl.trim()) return;

    let url = newLinkUrl.trim();
    if (!url.startsWith("http://") && !url.startsWith("https://")) {
      url = "https://" + url;
    }

    const newResource: Resource = { type: "link", name: newLinkName.trim(), url };
    const newResources = [newResource, ...resources];
    setResources(newResources);
    await saveResources(newResources);
    setNewLinkName("");
    setNewLinkUrl("");
    setShowLinkForm(false);
  };

  const deleteResource = async (index: number) => {
    const newResources = resources.filter((_, i) => i !== index);
    setResources(newResources);
    await saveResources(newResources);
  };

  const formatFileSize = (bytes?: number) => {
    if (!bytes) return "";
    if (bytes < 1024) return bytes + " o";
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " Ko";
    return (bytes / (1024 * 1024)).toFixed(1) + " Mo";
  };

  useEffect(() => {
    if (!projectId) return;
    handleFetchNudge();
  }, [projectId]);

  const handleGenerateAI = async () => {
    setIsGenerating(true);
    try {
      const res = await fetch(`/api/projects/${projectId}/generate`, { method: "POST" });
      if (res.ok) {
        const { data } = await res.json();
        setAiData(data);
      }
    } catch (err) {
      console.error("Erreur génération IA:", err);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleFetchNudge = async () => {
    try {
      const res = await fetch(`/api/projects/${projectId}/nudge`, { method: "POST" });
      if (res.ok) {
        const { data } = await res.json();
        setNudge(data);
      }
    } catch {}
  };

  const handleHeritage = async () => {
    try {
      const res = await fetch(`/api/projects/${projectId}/heritage`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reason: "Abandon temporaire" }),
      });
      if (res.ok) {
        const { data } = await res.json();
        setHeritage(data);
      }
    } catch {}
  };

  if (isLoading) {
    return (
      <main className="min-h-screen bg-slate-50">
        <div className="mx-auto max-w-4xl px-6 py-10">
          <div className="flex items-center justify-center py-20">
            <Loader2 className="size-8 animate-spin text-primary" />
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-slate-50">
      <div className="mx-auto max-w-4xl px-6 py-10">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900">Ressources</h1>
          <p className="mt-2 text-slate-600">
            {project?.title} — Gère les documents et liens
          </p>
        </div>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Ajouter une ressource</CardTitle>
            <CardDescription>
              Ajoute des PDF ou des liens pour enrichir ton projet
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div
              className="cursor-pointer rounded-lg border-2 border-dashed border-slate-300 p-6 text-center transition-colors hover:border-primary/50 hover:bg-primary/5"
              onClick={() => fileInputRef.current?.click()}
            >
              <Upload className="mx-auto mb-3 size-8 text-slate-400" />
              <p className="mb-1 text-sm font-medium text-slate-700">
                {isAdding ? "Ajout en cours..." : "Glisse-dépose ou clique pour ajouter un PDF"}
              </p>
              <p className="text-xs text-slate-500">Format accepté : PDF</p>
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,application/pdf"
                multiple
                onChange={handleFileUpload}
                className="hidden"
              />
            </div>

            {!showLinkForm ? (
              <Button variant="outline" onClick={() => setShowLinkForm(true)} className="w-full gap-2">
                <LinkIcon className="size-4" />
                Ajouter un lien
              </Button>
            ) : (
              <div className="rounded-lg border bg-slate-50 p-4">
                <div className="mb-3 flex items-center justify-between">
                  <p className="text-sm font-medium">Nouveau lien</p>
                  <Button variant="ghost" size="icon-sm" onClick={() => setShowLinkForm(false)}>
                    <X className="size-4" />
                  </Button>
                </div>
                <div className="space-y-2">
                  <Input placeholder="Nom du lien" value={newLinkName} onChange={(e) => setNewLinkName(e.target.value)} className="h-9" />
                  <Input placeholder="URL (ex: https://docs.example.com)" value={newLinkUrl} onChange={(e) => setNewLinkUrl(e.target.value)} className="h-9" />
                  <Button size="sm" onClick={addLink} disabled={isAdding || !newLinkName.trim() || !newLinkUrl.trim()} className="gap-2">
                    {isAdding ? <Loader2 className="size-4 animate-spin" /> : <Plus className="size-4" />}
                    Ajouter
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Ressources ({resources.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {resources.length > 0 ? (
              <div className="space-y-2">
                {resources.map((resource, index) => (
                  <div key={index} className="flex items-center justify-between rounded-lg border bg-white p-4 transition-colors hover:bg-slate-50">
                    <div className="flex items-center gap-4">
                      {resource.type === "pdf" ? (
                        <div className="flex size-10 items-center justify-center rounded-lg bg-red-100">
                          <FileText className="size-5 text-red-600" />
                        </div>
                      ) : (
                        <div className="flex size-10 items-center justify-center rounded-lg bg-blue-100">
                          <LinkIcon className="size-5 text-blue-600" />
                        </div>
                      )}
                      <div>
                        <p className="font-medium text-slate-900">{resource.name}</p>
                        <p className="text-xs text-slate-500">
                          {resource.type === "pdf" ? formatFileSize(resource.file_size) : resource.url}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <a href={resource.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 rounded-lg bg-primary/10 px-3 py-1.5 text-xs font-medium text-primary hover:bg-primary/20">
                        <ExternalLink className="size-3" />
                        Ouvrir
                      </a>
                      <Button variant="ghost" size="icon-sm" onClick={() => deleteResource(index)} className="text-slate-400 hover:text-red-600">
                        <Trash2 className="size-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="py-12 text-center">
                <FileText className="mx-auto mb-3 size-12 text-slate-300" />
                <p className="text-sm text-slate-500">Aucune ressource pour l&apos;instant.</p>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="mb-6 flex flex-wrap gap-3">
          <Button onClick={handleGenerateAI} disabled={isGenerating} className="gap-2">
            {isGenerating ? <Loader2 className="size-4 animate-spin" /> : <Sparkles className="size-4" />}
            {aiData ? "Régénérer l'IA" : "Générer IA"}
          </Button>
          <Button onClick={handleHeritage} variant="outline" className="gap-2">
            <Archive className="size-4" />
            Carte d'héritage
          </Button>
        </div>

        {nudge && (
          <Card className="mb-6 border-amber-200 bg-amber-50">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <AlertTriangle className="size-5 text-amber-500 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-amber-800">{nudge.nudgeMessage}</p>
                  <p className="text-sm text-amber-600 mt-1">Micro-objectif : {nudge.microObjective}</p>
                  <p className="text-xs text-amber-500 mt-1 italic">{nudge.encouragement}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {aiData && (
          <div className="mb-6">
            <div className="mb-4 flex gap-1 rounded-lg border bg-white p-1">
              {(['roadmap', 'pitch', 'readme', 'resources', 'heritage'] as const).map((tab) => {
                const labels: Record<string, string> = {
                  roadmap: 'Roadmap',
                  pitch: 'Pitch',
                  readme: 'README',
                  resources: 'Ressources',
                  heritage: 'Héritage',
                };
                return (
                  <button
                    key={tab}
                    onClick={() => setActiveAiTab(tab)}
                    className={`flex-1 rounded-md px-3 py-2 text-sm font-medium transition-colors ${
                      activeAiTab === tab
                        ? 'bg-primary text-white'
                        : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    {labels[tab]}
                  </button>
                );
              })}
            </div>

            {activeAiTab === 'roadmap' && aiData.roadmap && (
              <div className="space-y-4">
                {aiData.roadmap.map((day: any, i: number) => (
                  <Card key={i}>
                    <CardHeader className="pb-2">
                      <div className="flex items-center gap-2">
                        <Calendar className="size-4 text-primary" />
                        <CardTitle className="text-base">Jour {day.day ?? i + 1}{day.title ? ` — ${day.title}` : ''}</CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <ul className="list-disc pl-5 space-y-1">
                        {(day.tasks ?? day.items ?? []).map((task: string, j: number) => (
                          <li key={j} className="text-sm text-slate-700">{task}</li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            {activeAiTab === 'pitch' && aiData.pitch && (
              <Card>
                <CardContent className="p-6 space-y-4">
                  {aiData.pitch.tagline && (
                    <p className="text-lg font-bold text-slate-900">{aiData.pitch.tagline}</p>
                  )}
                  {aiData.pitch.description && (
                    <p className="text-sm text-slate-600">{aiData.pitch.description}</p>
                  )}
                  {aiData.pitch.highlights && (
                    <ul className="list-disc pl-5 space-y-1">
                      {aiData.pitch.highlights.map((h: string, i: number) => (
                        <li key={i} className="text-sm text-slate-700">{h}</li>
                      ))}
                    </ul>
                  )}
                </CardContent>
              </Card>
            )}

            {activeAiTab === 'readme' && aiData.readme && (
              <Card>
                <CardContent className="p-6">
                  <pre className="whitespace-pre-wrap rounded-lg bg-slate-900 p-4 text-sm text-slate-100 overflow-x-auto">
                    <code>{typeof aiData.readme === 'string' ? aiData.readme : aiData.readme.content ?? JSON.stringify(aiData.readme, null, 2)}</code>
                  </pre>
                </CardContent>
              </Card>
            )}

            {activeAiTab === 'resources' && aiData.suggestedResources && (
              <div className="space-y-3">
                {aiData.suggestedResources.map((res: any, i: number) => (
                  <Card key={i}>
                    <CardContent className="flex items-center justify-between p-4">
                      <div className="flex items-center gap-3">
                        <div className="flex size-9 items-center justify-center rounded-lg bg-blue-100">
                          <LinkIcon className="size-4 text-blue-600" />
                        </div>
                        <div>
                          <p className="font-medium text-slate-900">{res.title ?? res.name}</p>
                          <span className="inline-block rounded-full bg-slate-100 px-2 py-0.5 text-xs text-slate-500">{res.type}</span>
                        </div>
                      </div>
                      {res.url && (
                        <a href={res.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 rounded-lg bg-primary/10 px-3 py-1.5 text-xs font-medium text-primary hover:bg-primary/20">
                          <ExternalLink className="size-3" />
                          Ouvrir
                        </a>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            {activeAiTab === 'heritage' && (
              heritage ? (
                <Card>
                  <CardContent className="p-6 space-y-4">
                    {heritage.summary && (
                      <div>
                        <h4 className="text-sm font-semibold text-slate-900 mb-1">Résumé</h4>
                        <p className="text-sm text-slate-600">{heritage.summary}</p>
                      </div>
                    )}
                    {heritage.whatWorked && (
                      <div>
                        <h4 className="text-sm font-semibold text-green-700 mb-1">Ce qui a fonctionné</h4>
                        <p className="text-sm text-slate-600">{heritage.whatWorked}</p>
                      </div>
                    )}
                    {heritage.whatDidnt && (
                      <div>
                        <h4 className="text-sm font-semibold text-red-700 mb-1">Ce qui n&apos;a pas fonctionné</h4>
                        <p className="text-sm text-slate-600">{heritage.whatDidnt}</p>
                      </div>
                    )}
                    {heritage.remainingTasks && (
                      <div>
                        <h4 className="text-sm font-semibold text-amber-700 mb-1">Tâches restantes</h4>
                        <p className="text-sm text-slate-600">{heritage.remainingTasks}</p>
                      </div>
                    )}
                    {heritage.handoffNotes && (
                      <div>
                        <h4 className="text-sm font-semibold text-slate-900 mb-1">Notes de passation</h4>
                        <p className="text-sm text-slate-600">{heritage.handoffNotes}</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ) : (
                <Card>
                  <CardContent className="py-12 text-center">
                    <Archive className="mx-auto mb-3 size-12 text-slate-300" />
                    <p className="text-sm text-slate-500">Aucune carte d&apos;héritage pour l&apos;instant.</p>
                  </CardContent>
                </Card>
              )
            )}
          </div>
        )}

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="size-4" />
              Journal de progression
            </CardTitle>
          </CardHeader>
          <CardContent>
            {progressLog ? (
              <p className="text-sm text-slate-700 whitespace-pre-wrap">{progressLog}</p>
            ) : (
              <p className="text-sm text-slate-500 italic">Aucun journal de progression pour l&apos;instant.</p>
            )}
          </CardContent>
        </Card>
      </div>
    </main>
  );
}
